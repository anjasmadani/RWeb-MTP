<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class M_daftar extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}

	function get(){
		$query = $this->db->query('SELECT * FROM dosen');
        return $query->result();
	}
	public function getdata($key){
		$this->db->where('id_mtp',$key);
		$hasil = $this->db->get('data_mtp');
		return $hasil;
	}
	public function getupdate($key,$data){
		$this->db->where('id_mtp',$key);
		 $this->db->update('data_mtp',$data);
	}
	public function getinsert($data){
		 $this->db->insert('data_mtp',$data);
	}
	public function getdelete($key){
		$this->db->where('id_mtp',$key);
		 $this->db->delete('data_mtp');
	}
}
?>
