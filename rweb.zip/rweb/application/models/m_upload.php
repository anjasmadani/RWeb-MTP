<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class M_upload extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}

	function get(){
		$query = $this->db->query('SELECT * FROM dosen');
        return $query->result();
	}
	public function getdata($key){
		$this->db->where('id',$key);
		$hasil = $this->db->get('data_mtp');
		return $hasil;
	}
	public function getupdate($key,$data){
		$this->db->where('id',$key);
		 $this->db->update('data_mtp',$data);
	}
	public function getinsert($data){
		 $this->db->insert('data_mtp',$data);
	}
	public function getdelete($key){
		$this->db->where('id',$key);
		 $this->db->delete('data_mtp');
	}
}
?>