<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Daftar extends CI_Controller {
	function __construct()
    {
        parent:: __construct();
        $this->load->model('m_daftar','', TRUE);
    }
	public function index()
	{
		$data['content'] = 'v_daftar';
		$data['judul'] = 'Daftar MTP';
		$data['dosen'] = $this->m_daftar->get('dosen');
		$this->load->view('v_daftar',$data);
	}
	public function simpan(){
		$key = $this->input->post('id_mtp');
		$data['jenis_mtp'] = $this->input->post('jenis');
		$data['nama_kelompok'] = $this->input->post('nama_kelompok');
		$data['nama_ketua'] = $this->input->post('ketua');
		$data['kontak_ketua'] = $this->input->post('kontak_ketua');
		$data['anggota1'] = $this->input->post('anggota1');
		$data['anggota2'] = $this->input->post('anggota2');
		$data['anggota3'] = $this->input->post('anggota3');
		$data['anggota4'] = $this->input->post('anggota4');
		$data['anggota5'] = $this->input->post('anggota5');
		$data['anggota6'] = $this->input->post('anggota6');
		$data['dospem'] = $this->input->post('dospem');
		$data['judul'] = $this->input->post('judul');
		$data['tempat'] = $this->input->post('tempat');

		$this->load->model('m_daftar');
		$query = $this->m_daftar->getdata($key);
		if ($query->num_rows()>0) {
			$this->m_daftar->getupdate($key,$data);
		}
		else{
			$this->m_daftar->getinsert($data);
		}
		redirect('daftar');
	}
}