<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {

	public function index()
	{
		$isi['content'] = 'v_upload';
		$isi['judul'] = 'Upload Laporan MTP';
		$isi['data'] = $this->db->get('data_mtp');
		$this->load->view('v_upload',$isi);
	}
	public function uploadfile()
	{
		$isi['content'] = 'v_upload';
		$isi['judul'] = 'Upload Laporan MTP';

		$key = $this->uri->segment(3);
		$this->db->where('nama_kelompok',$key);
		$query = $this->db->get('data_mtp');
		if ($query->num_rows()>0) {
			foreach ($query->result() as $row) {
				$isi['nama_kelompok']	= $row->nama_kelompok;
				$isi['nama_ketua']		= $row->nama_ketua;
				$isi['dospem']			= $row->dospem;
				$isi['judul']			= $row->judul;
			}
		}
		else{
				$isi['nama_kelompok']	= '';
				$isi['nama_ketua']		= '';
				$isi['dospem']			= '';
				$isi['judul']			= '';
		}
		$this->load->view('v_upload',$isi);
	}
	private function _do_upload(){
		$config['upload_path'] 		= 'assets/img/';
		$config['allowed_types'] 	= 'gif|jpg|png';
		$config['file_name'] 			= $id_username;
		$config['max_size'] 			= 0;
		$config['max_widht'] 			= 0;
		$config['max_height']  			= 0;

 
		$this->load->library('upload', $config);
		if (!$this->upload->do_upload('foto')) {
			$this->session->set_flashdata('msg', $this->upload->display_errors('',''));
			redirect('admin');
		}
		return $this->upload->data('file_name');
	}
}