<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends CI_Controller {
	function __construct()
    {
        parent:: __construct();
        $this->load->model('m_data','', TRUE);
    }
	public function index()
	{
		$data['content'] = 'v_data';
		$data['judul'] = 'Data MTP';
		$data['data'] = $this->db->get('data_mtp');
		$this->load->view('v_data',$data);
	}

}