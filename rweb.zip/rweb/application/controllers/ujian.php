<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ujian extends CI_Controller {

	public function index()
	{
		$isi['content'] = 'v_ujian';
		$isi['judul'] = 'Ujian MTP';
		$isi['data'] = $this->db->get('data_mtp');
		$this->load->view('v_ujian',$isi);
	}
	public function daftarujian()
	{
		$isi['content'] = 'v_ujian';
		$isi['judul'] = 'Ujian MTP';

		$key = $this->uri->segment(3);
		$this->db->where('nama_kelompok',$key);
		$query = $this->db->get('data_mtp');
		if ($query->num_rows()>0) {
			foreach ($query->result() as $row) {
				$isi['nama_kelompok']	= $row->nama_kelompok;
				$isi['nama_ketua']		= $row->nama_ketua;
				$isi['dospem']			= $row->dospem;
				$isi['judul']			= $row->judul;
			}
		}
		else{
				$isi['nama_kelompok']	= '';
				$isi['nama_ketua']		= '';
				$isi['dospem']			= '';
				$isi['judul']			= '';
		}
		$this->load->view('v_ujian',$isi);
	}
}