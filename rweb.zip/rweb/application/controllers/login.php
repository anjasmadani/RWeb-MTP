<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->view('v_login');
	}
	public function getlogin()
	{
		if (isset($_POST['submit'])) {
			$u = $this->input->post('username');
			$p = $this->input->post('password');
			$this->load->model('m_login');
			$this->m_login->getlogin($u,$p);
		}else{
			$this->load->view('v_login');
		}
	} 
}