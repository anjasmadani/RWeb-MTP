                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>index.php/dashboard" class="nav-link"><i class="fe fe-home"></i> Dashboard</a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>index.php/daftar" class="nav-link" data-toggle="dropdown"><i class="fe fe-file"></i> Daftar MTP</a>
                  </li>
                  <li class="nav-item dropdown">
                    <a href="<?php echo base_url();?>index.php/data" class="nav-link" data-toggle="dropdown"><i class="fe fe-file-text"></i> Data MTP</a>
                  </li>
                </ul>