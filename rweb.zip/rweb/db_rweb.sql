-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 15 Jul 2019 pada 17.15
-- Versi server: 10.1.30-MariaDB
-- Versi PHP: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_rweb`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_mtp`
--

CREATE TABLE `data_mtp` (
  `id_mtp` int(100) NOT NULL,
  `jenis_mtp` varchar(100) NOT NULL,
  `nama_kelompok` varchar(100) NOT NULL,
  `nama_ketua` varchar(100) NOT NULL,
  `kontak_ketua` varchar(100) NOT NULL,
  `anggota1` varchar(100) NOT NULL,
  `anggota2` varchar(100) NOT NULL,
  `anggota3` varchar(100) NOT NULL,
  `anggota4` varchar(100) NOT NULL,
  `anggota5` varchar(100) NOT NULL,
  `anggota6` varchar(100) NOT NULL,
  `dospem` varchar(100) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `tempat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_mtp`
--

INSERT INTO `data_mtp` (`id_mtp`, `jenis_mtp`, `nama_kelompok`, `nama_ketua`, `kontak_ketua`, `anggota1`, `anggota2`, `anggota3`, `anggota4`, `anggota5`, `anggota6`, `dospem`, `judul`, `tempat`) VALUES
(1, 'Baru', 'marvel', 'fadjry', '1213', 'ironman', 'captamerrica', 'captmarvel', 'vision', 'thor', 'spiderman', 'Supriyanto,', 'webprofile', 'wakanda'),
(2, 'Baru', 'Avengers', 'Galih', '212', 'Albab', 'Anjas', 'Ipal', 'Wahyu', 'Bayu', 'Bagus', 'Ahmad', 'Sistem Perbankan', 'Bank BNI');

-- --------------------------------------------------------

--
-- Struktur dari tabel `dosen`
--

CREATE TABLE `dosen` (
  `id_dosen` int(10) NOT NULL,
  `nama_dosen` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `dosen`
--

INSERT INTO `dosen` (`id_dosen`, `nama_dosen`) VALUES
(19087601, 'Nur Rochmah Dyah Pujiastuti, S.T, M.Kom.'),
(505118901, 'Ahmad Azhari, S.Kom., M.Eng.'),
(523068801, 'Supriyanto, S.T., M.T.'),
(523077902, 'Ardiansyah, S.T., M. Cs'),
(524118801, 'Adhi Prahara, S.Si., M.Cs.'),
(526018502, 'Arfiani Nur Khusna, S.T., M.Kom.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `nim` int(10) NOT NULL,
  `nama_mhs` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`nim`, `nama_mhs`, `username`, `password`) VALUES
(1600018118, 'Anjas Madani Tahir', '1600018118', '59c14704c4371ed88082758880e153b2');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_mtp`
--
ALTER TABLE `data_mtp`
  ADD PRIMARY KEY (`id_mtp`);

--
-- Indeks untuk tabel `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`id_dosen`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`nim`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_mtp`
--
ALTER TABLE `data_mtp`
  MODIFY `id_mtp` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
